@extends('layouts.app')

@section('content')
    <h2>Register Here</h2>
@endsection